#!/usr/bin/env bash
set -euo pipefail

if ! command -v java >/dev/null 2>&1; then
  echo 'Java 21 is required. Install a JDK before building.' >&2
  exit 1
fi
if [[ -z "${ANDROID_HOME:-}" && -z "${ANDROID_SDK_ROOT:-}" ]]; then
  echo 'Android SDK not found. Install Android Studio/SDK and set ANDROID_HOME.' >&2
  exit 1
fi

npm install --no-audit --no-fund
npm run build
if [[ ! -d android ]]; then
  npx cap add android
fi
npx cap sync android
cat > android/variables.gradle <<'GRADLE'
ext {
    minSdkVersion = 23
    compileSdkVersion = 35
    targetSdkVersion = 35
    androidxActivityVersion = '1.10.1'
    androidxAppCompatVersion = '1.7.0'
    androidxCoordinatorLayoutVersion = '1.2.0'
    androidxCoreVersion = '1.16.0'
    androidxFragmentVersion = '1.8.6'
    coreSplashScreenVersion = '1.0.1'
    androidxWebkitVersion = '1.12.1'
    junitVersion = '4.13.2'
    androidxJunitVersion = '1.2.1'
    androidxEspressoCoreVersion = '3.6.1'
    cordovaAndroidVersion = '14.0.1'
}
GRADLE
(cd android && ./gradlew assembleDebug)
echo "APK: android/app/build/outputs/apk/debug/app-debug.apk"
