# LeadPilot — Automated Android Prospecting CRM

React + Capacitor Android app with a separate Node.js API for business discovery and public website enrichment.

## Automated features
- Google Places API (New) discovery by city and category (up to 20 listings per search response).
- Imports business name, address, phone, website, operating status and Maps link when available.
- Automatically checks each discovered business website for public `mailto:` links, visible email patterns and Instagram/Facebook/LinkedIn links; also supports a manual re-check.
- Enrichment respects the site's `robots.txt`, uses request timeouts, blocks private/local network destinations and only fetches public HTML pages.
- Saves enriched contact/profile candidates to the lead record; user should verify before outreach.
- Local follow-up notifications for dated leads in the installed Android app; startup discovery is optional.
- Outreach statuses: Not contacted, Contacted, Responded, Meeting booked, Converted, Not interested.
- Priority, stages, search, filters, CSV import/export, local persistence and summary dashboard.

## Android compatibility target
- Android 6.0 (API 23) minimum; includes Android 10+ devices.
- Target/compile SDK 35.
- The normal `assembleDebug` output is a universal APK containing the ABIs enabled by the Capacitor Android project (no ABI split is configured).
- Supports common Android phone manufacturers; layout is responsive rather than device-brand-specific. Actual device compatibility still requires testing.

## Requirements
- Node.js 20+
- Android Studio and Android SDK
- Google Cloud project with Places API (New) enabled and billing configured.
- A hosted backend for the Android APK. The app must reach this backend over HTTPS.

## Configure backend
```bash
npm install
cp .env.example .env
# Set GOOGLE_MAPS_API_KEY in .env (server-side key, restricted to Places API)
npm run server
```
The API listens on port 8787 by default. Deploy it to a trusted HTTPS host. Configure allowed `APP_ORIGIN` values for your deployment.

## Run web app
```bash
npm run dev
```
Open Settings and set the API server URL, for example `https://your-api.example.com`. Then use Discover.

## Build universal debug APK locally
Install Android Studio, Android SDK Platform 35, Build Tools 35, and JDK 21. Set `ANDROID_HOME` or `ANDROID_SDK_ROOT`, then run:
```bash
./scripts/build-android.sh
```
Or open Android Studio with `npx cap open android` after `npx cap sync android`, then select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

A GitHub Actions workflow is included at `.github/workflows/android-debug-apk.yml`. Push the project to a GitHub repository and run the **Build universal Android debug APK** workflow; it uploads the debug APK as a downloadable workflow artifact.
In Android Studio choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
Expected debug APK: `android/app/build/outputs/apk/debug/app-debug.apk`. The APK is universal across the ABIs included in the build; it is not tied to a Motorola or other manufacturer.

For local notifications, grant notification permission on Android 13+ when prompted. Follow-up notifications are scheduled for 9:00 AM local time on each saved follow-up date.

## Important limitations
- Google Places provides business listing data, not a guaranteed source of emails or social profiles. Text Search supports up to 20 results per page and up to 60 across pages, subject to API limits. See official documentation: https://developers.google.com/maps/documentation/places/web-service/text-search
- Website enrichment only inspects publicly accessible HTML on the business website. It does not bypass logins, CAPTCHAs, paywalls, robots rules, or platform restrictions. Sites may block automated requests or hide contacts in scripts.
- This first version extracts candidate public contact links; it cannot guarantee that an address is current, monitored, or suitable for marketing. Verify and respect opt-outs and applicable Indian privacy/anti-spam laws.
- Social profile matching is limited to links explicitly published on the website. A separate Google search shortcut remains available for manual verification.
- Local notifications require the native Android build and permission. Browser preview does not provide native Android notification behavior.
- Data is local to the app installation. Export CSV backups regularly. There is no cloud sync or multi-user account in this starter.
- Automated bulk email/WhatsApp sending is intentionally not enabled. Use permission-based outreach and approved provider APIs only.

## Build the APK using GitHub Actions (no local Android Studio required)
1. Create a new **private** GitHub repository.
2. Extract this ZIP and upload all project files and folders to the repository root (including the hidden `.github` folder).
3. Commit the files to the `main` branch.
4. Open the repository's **Actions** tab.
5. Select **Build universal Android debug APK** and choose **Run workflow** (or let the first push start it).
6. Wait for the workflow to finish successfully.
7. Open the completed workflow run and download the **LeadPilot-universal-debug-apk** artifact.
8. Extract the artifact ZIP; it contains `app-debug.apk`.

The workflow targets Android API 23+ (Android 6.0+) and produces a standard debug APK with no ABI split filters. It has not been run from this environment. A successful green GitHub Actions run is required before treating the APK as built. The APK is unsigned for release distribution and is intended for testing/sideloading.
