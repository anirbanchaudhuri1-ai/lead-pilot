import { LocalNotifications } from '@capacitor/local-notifications';
export async function syncFollowUpNotifications(leads){
  try{
    const perm=await LocalNotifications.checkPermissions();
    const granted=perm.display==='granted'||(await LocalNotifications.requestPermissions()).display==='granted';
    if(!granted)return;
    const pending=await LocalNotifications.getPending();
    const ids=pending.notifications.filter(n=>n.extra?.leadpilot).map(n=>n.id);
    if(ids.length)await LocalNotifications.cancel({notifications:ids.map(id=>({id}))});
    const now=new Date(), notifications=[];
    leads.filter(l=>l.followUp&&l.name).forEach((l,index)=>{
      const [y,m,d]=l.followUp.split('-').map(Number);
      const at=new Date(y,m-1,d,9,0,0);
      if(at<=now)return;
      notifications.push({id:Math.abs(hash(`${l.name}-${l.followUp}-${index}`)),title:'Lead follow-up due',body:`Follow up with ${l.name}`,schedule:{at},extra:{leadpilot:true,leadName:l.name}});
    });
    if(notifications.length)await LocalNotifications.schedule({notifications});
  }catch(e){console.warn('Local reminders are available in the installed Android app:',e)}
}
function hash(s){let h=0;for(let i=0;i<s.length;i++)h=(h*31+s.charCodeAt(i))|0;return h||1}
